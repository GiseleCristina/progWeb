<?php
// Here you can initialize variables that will for your tests
